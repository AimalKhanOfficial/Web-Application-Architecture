import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Created by 986298 on 5/29/2018.
 */
public class CalculatorServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        StringBuilder response = new StringBuilder();
        response.append("<!DOCTYPE html>");
        response.append("<html>");
        response.append("<head>");
        response.append("<title>Calculator</title>");
        response.append("</head>");
        response.append("<body>");
        response.append("<form method='post' action='CalculatorServlet'>");
        response.append("<input type='text' name='x' value='"+req.getSession().getAttribute("x")+"'>");
        response.append("<label>+</label>");
        response.append("<input type='text' name='y' value='"+req.getSession().getAttribute("y")+ "'>");
        response.append("<label>=</label>");
        response.append("<input type='text' name='addResult' value='"+req.getSession().getAttribute("addResult")+"'>");
        response.append("<br/>");
        response.append("<input type='text' name='a' value='"+req.getSession().getAttribute("a")+"'>");
        response.append("<label>*</label>");
        response.append("<input type='text' name='b' value='"+req.getSession().getAttribute("b") +"'>");
        response.append("<label>=</label>");
        response.append("<input type='text' name='mulResult' value='"+req.getSession().getAttribute("mulResult")+"'>");
        response.append("<br/>");
        response.append("<input type='submit'>");
        response.append("</form>");
        response.append("</body>");
        response.append("</html>");

        PrintWriter writer = resp.getWriter();
        writer.print(response);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int x = Integer.parseInt(req.getParameter("x"));
        int y = Integer.parseInt(req.getParameter("y"));
        int a = Integer.parseInt(req.getParameter("a"));
        int b = Integer.parseInt(req.getParameter("b"));

        req.getSession().setAttribute("x", x);
        req.getSession().setAttribute("y", y);
        req.getSession().setAttribute("a", a);
        req.getSession().setAttribute("b", b);
        req.getSession().setAttribute("addResult", x + y);
        req.getSession().setAttribute("mulResult", a * b);

        resp.sendRedirect("/CalculatorServlet");
    }
}

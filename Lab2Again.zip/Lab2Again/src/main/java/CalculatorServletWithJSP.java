import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by 986298 on 5/29/2018.
 */
public class CalculatorServletWithJSP extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int x = Integer.parseInt(req.getParameter("x"));
        int y = Integer.parseInt(req.getParameter("y"));
        int a = Integer.parseInt(req.getParameter("a"));
        int b = Integer.parseInt(req.getParameter("b"));

        req.getSession().setAttribute("xEL", x);
        req.getSession().setAttribute("yEL", y);
        req.getSession().setAttribute("aEL", a);
        req.getSession().setAttribute("bEL", b);
        req.getSession().setAttribute("addResultEL", x + y);
        req.getSession().setAttribute("mulResultEL", a * b);

        resp.sendRedirect("index.jsp");
    }
}
